from django.contrib import admin

from .models import Society
admin.site.register(Society)

