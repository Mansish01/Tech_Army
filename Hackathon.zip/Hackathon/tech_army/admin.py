from django.contrib import admin

from .models import Society,SharedTextarea
admin.site.register(Society)
admin.site.register(SharedTextarea)
